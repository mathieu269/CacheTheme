<?php if(!defined('PLX_ROOT')) exit; ?>

	<aside class="aside col sml-12 med-4" role="complementary">

		<h3>
			<?php $plxShow->lang('CATEGORIES'); ?>
		</h3>

		<ul class="cat-list unstyled-list">
			<?php $plxShow->catList('','<li id="#cat_id"><a class="#cat_status" href="#cat_url" title="#cat_name">#cat_name</a> (#art_nb)</li>'); ?>
		</ul>

		<?php
			if (!class_exists("CacheTheme")) {
				
				require "sidebar/nuageMotsCles_archives.php";
				
			} else {
				
				CacheTheme::cache([
					"fichier" => "sidebar/nuageMotsCles_archives.php",
					"crochets" => "EditArticle|DelArticle",
				]);
				
			}
		?>
		
		
		<h3>
			<?php $plxShow->lang('LATEST_COMMENTS'); ?>
		</h3>

		<ul class="lastcom-list unstyled-list">
			<?php $plxShow->lastComList('<li><a href="#com_url">#com_author '.$plxShow->getLang('SAID').' : #com_content(34)</a></li>'); ?>
		</ul>

		<h3>
			RSS
		</h3>
			<ul class="rss-list unstyled-list">
				<li><a href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" title="<?php $plxShow->lang('ARTICLES_RSS_FEEDS'); ?>"><?php $plxShow->lang('ARTICLES'); ?></a></li>
				<li><a href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires'); ?>" title="<?php $plxShow->lang('COMMENTS_RSS_FEEDS') ?>"><?php $plxShow->lang('COMMENTS'); ?></a></li>
			</ul>

	</aside>
