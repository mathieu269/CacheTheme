
<h3>
	<?php $plxShow->lang('LATEST_ARTICLES'); ?>
</h3>

<ul class="lastart-list unstyled-list">
	<?php $plxShow->lastArtList('<li><a class="#art_status" href="#art_url" title="#art_title">#art_title</a></li>'); ?>
</ul>


<h3>
	<?php $plxShow->lang('TAGS'); ?>
</h3>

<ul class="tag-list">
	<?php $plxShow->tagList('<li class="tag #tag_size"><a class="#tag_status" href="#tag_url" title="#tag_name">#tag_name</a></li>'); ?>
</ul>


<h3>
	<?php $plxShow->lang('ARCHIVES'); ?>
</h3>

<ul class="arch-list unstyled-list">
	<?php $plxShow->archList('<li id="#archives_id"><a class="#archives_status" href="#archives_url" title="#archives_name">#archives_name</a> (#archives_nbart)</li>'); ?>
</ul>
